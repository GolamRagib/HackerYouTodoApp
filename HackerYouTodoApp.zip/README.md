# HackerYouTodoApp
1. `git clone https://github.com/GolamRagib/HackerYouTodoApp.git`
2. `cd HackerYouTodoApp`
3. `npm install -g webpack webpack-dev-server`
4. `npm install`
5. `webpack-dev-server`
6. …
7. Profit!

I think that's how it works.
