import React from 'react';
import ReactDOM from 'react-dom';

// Include your React components like this:
import TodoApp from './components/todo_app.jsx';

ReactDOM.render(<TodoApp />, document.getElementById("placeholder"));
